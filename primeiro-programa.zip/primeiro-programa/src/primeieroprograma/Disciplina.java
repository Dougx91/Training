package primeieroprograma;

public class Disciplina {

	private double nota;
	private String disciplina;
	String v[] = new String[4];
	int i = 0;

	public double getNota() {
		return nota;
	}

	
	public void definirDisciplina(String e) {
			v[i] = e;
			i++;
		}
		
	public String mostrarDisciplina() {
		int i = 0;
		for (i = 0; i < 1; i++) {
		}
		
		return v[i];
			
	}
		

	public void setNota(double nota) {
		this.nota = nota;
	}

	public String getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}

	@Override
	public String toString() {
		return "Disciplina [nota=" + nota + ", disciplina=" + disciplina + "]";
	}

}
