package primeieroprograma;

import javax.swing.JOptionPane;

public class PrimeiroPrograma {
	
	public static void main(String[] args) {

		
		/*String nome = JOptionPane.showInputDialog("Qual seu nome?");
		String idade = JOptionPane.showInputDialog("Qual sua idade?");
		String dataNas = JOptionPane.showInputDialog("Qual sua data de nascimento?");
		String cpf = JOptionPane.showInputDialog("Qual � o seu CPF?");*/
		String soma = "";
		String v[] = new String[4];
		
		Aluno a = new Aluno();
		
		/*a.setNome(nome);
		a.setIdade(Integer.parseInt(idade));
		a.setDataNas(dataNas);
		a.setCPF(cpf);*/
		

		
		for (int pos = 1; pos < 4; pos++) {
			String disciplinas = JOptionPane.showInputDialog("Disciplina " + pos + " ?");
			String nota = JOptionPane.showInputDialog("Nota " + pos + " ?");
			Disciplina disc = new Disciplina();
			disc.setDisciplina(disciplinas);
			disc.setNota(Double.parseDouble(nota));
			a.getDisciplinas().add(disc);
			disc.definirDisciplina(disciplinas);
			v[pos] = disciplinas;
			if (pos == 4) {
				soma += disciplinas + " Posi��o" +"("+pos+")" + " ?";	
			}else if (pos == 3) {
				
				soma += disciplinas + " Posi��o" +"("+pos+")" + " ou ";	
			}else {
				soma += disciplinas + " Posi��o" +"("+pos+")" + ", ";
			}
			
		
		}
		
		int escolha = JOptionPane.showConfirmDialog(null, " Deseja remover alguma disciplina? ");
		
		if (escolha == 0) {
			int i = 0;
			int pos = 1;
			while (escolha == 0) {
			String disciplina = JOptionPane.showInputDialog(soma);
			a.getDisciplinas().remove(Integer.parseInt(disciplina) - pos);
			pos++;
			JOptionPane.showMessageDialog(null, ("Removido com sucesso a disciplina " + disciplina));
			escolha = JOptionPane.showConfirmDialog(null, "Deseja remover mais algum?");
			}
		}
		
		int g = JOptionPane.showConfirmDialog(null, "Gostaria de saber se voc� foi aprovado?");
		
		if(g == 0) {
			JOptionPane.showMessageDialog(null, a.getMediaNota());
		}
		
	}

}
