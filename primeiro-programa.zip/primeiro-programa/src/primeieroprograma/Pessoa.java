package primeieroprograma;

public class Pessoa {

}
