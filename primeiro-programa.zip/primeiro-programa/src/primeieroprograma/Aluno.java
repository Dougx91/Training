package primeieroprograma;

import java.util.ArrayList;
import java.util.List;

public class Aluno {
	
	private String nome;
	private int idade;
	private String naturalidade;
	private String nomeEscola;
	private String dataNas;
	private String cpf;
	
	private List <Disciplina> disciplinas = new ArrayList<Disciplina>();//foi criado uma lista, da classe List, para guardar os objetos dentro da variavel disciplinas
	// os objetos a serem guardados tem que ser da classe Disciplina

	public List<Disciplina> getDisciplinas() {
		return disciplinas;
	}

	public void setDisciplinas(List<Disciplina> disciplinas) {
		this.disciplinas = disciplinas;
	}
	
	public String getMediaNota() {
		double soma = 0.0;
		for (Disciplina disciplina : disciplinas) {// Eu instanciei um outro objeto da classe Disciplina com o nome disciplina (em minusculo)
			soma += disciplina.getNota();// disciplina ir� receber um por um os objetos da lista de objetos da instancia "disciplinas". Esse procedimento de receber
		}// um objeto por vez � chamado de for each. Da mesma forma que um vetor, o primeiro objeto sempre comecar� da posi��o 0, e o restante assim por diante. 
		//Na segunda linha do for, a instancia discplina recebe o primeiro objeto da posicao 0, e esse objeto � da classe Disciplina. 
		//Depois, volta para o for, e o segundo objeto da posicao 1 � tratado.
		// Por tatnto, disciplina consegue chamar o metodo getNota pois este faz parte dessa classe.
		double media = soma / disciplinas.size();// disciplinas.size eu consigo saber quantos objetos eu tenho dentro da lista disciplinas. Ou seja, vou dividir a variavel 
		//soma com a quantidade de objetos que tenho para saber a media de notas. Esse tipo de procedimento � um meio para automatizar o c�digo em vez de ficar
		// digitando quantos objetos eu tenho para realizar a divis�o. Aqui eu consigo definir uma divis�o autom�tica.
		
		if(media > 50) {
			if(media > 70) {
				return "Aluno aprovado!";
			}else {
				return "Aluno em recupera��o!";
				
			}
		}else {
			return "Aluno reprovado!";
			
		}
		
	}

	public String getCPF() {
		return cpf;
	}
	
	public void setCPF(String cpf) {
		this.cpf = cpf;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getDataNas() {
		return dataNas;
	}
	
	public void setDataNas(String dataNas) {
		this.dataNas = dataNas;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public String getNaturalidade() {
		return naturalidade;
	}
	public void setNaturalidade(String naturalidade) {
		this.naturalidade = naturalidade;
	}
	
	public void nomeEscola(String escola) {
		this.nomeEscola = escola;
	
	}


	@Override
	public String toString() {
		return "Aluno [nome=" + nome + ", idade=" + idade + ", naturalidade=" + naturalidade + ", nomeEscola="
				+ nomeEscola + ", dataNas=" + dataNas + ", cpf=" + cpf + "]";
	}

	
	}
	
	
	
	


